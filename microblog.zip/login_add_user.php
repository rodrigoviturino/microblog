<?php 

require_once "./config/Database.php";

$teste = new Database();

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $teste->adicionar($nome, $email, $senha);

        header("Location: login.php");

?>